def myfunc():
    print('hello')

def sub():
	return False
