from samp1 import myfunc
from samp1 import sub
a=sub()
print(a==0)
myfunc()
