A=1
B=2
print(A)
print(B)